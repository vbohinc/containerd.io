# Example Shim

This directory provides skeleton code as the starting point for creating a Runtime v2 shim.
This allows runtime authors to quickly bootstrap new shim implementations.

For full documentation on building a shim for containerd, see the [Shim Documentation](../README.md) file.
